<?php
/**
 * 生成网站地图
 *
 * @version        $Id: makehtml_map.php 1 11:17 2010年7月19日Z tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");

//var_dump(getAllTopId());exit;

if(empty($dopost))
{
    ShowMsg("参数错误!","-1");
    exit();
}

if($dopost=="sitemap2")
{
	require_once(DEDEINC."/sitemap.class.php");
	require_once(DEDEINC."/dedetag.class.php");
	$sm = new SiteMap();
	$maplist = $sm->GetSiteMap($dopost);
    $murl = $cfg_cmspath."/sitemap.html";
    $tmpfile = $cfg_basedir.$cfg_templets_dir."/map/sitemap2.htm";
	//echo $tmpfile;exit;
	$dtp = new DedeTagParse();
	//获取模板字符串
	$dtp->LoadTemplet($tmpfile);
	//var_dump($dtp->SourceString);exit;
	$dtp->SaveTo($cfg_basedir.$murl);
	$dtp->Clear();
	echo "<a href='$murl' target='_blank'>成功更新文件: $murl 浏览...</a>";
}
else
{
	require_once(DEDEINC."/arc.rssview.class.php");
	require_once DEDEINC."/arc.partview.class.php";
	if(empty($cfg_cmspath)){$cfg_cmspath='/';}
	$murl=$cfg_cmspath. $dopost.'.xml';
	//var_dump($murl);exit;
	if(!empty($dopost)){
	$pv = new PartView();
	$pv->SetTemplet($cfg_basedir . $cfg_templets_dir . '/map' .'/'. $dopost.'.xml');
	//var_dump($cfg_basedir . $cfg_templets_dir . '/plus' .'/'. $dopost.'.xml');exit;
	$pv->SaveToHtml(dirname(__FILE__).'/../'. $dopost.'.xml');
	echo "<a href='$murl' target='_blank'>成功更新文件: $murl 浏览...</a>";
	}
}
exit();